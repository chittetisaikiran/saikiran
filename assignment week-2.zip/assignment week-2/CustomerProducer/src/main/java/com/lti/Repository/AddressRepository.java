package com.lti.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lti.model.Address;

public interface AddressRepository  extends JpaRepository<Address, Integer> {

}
