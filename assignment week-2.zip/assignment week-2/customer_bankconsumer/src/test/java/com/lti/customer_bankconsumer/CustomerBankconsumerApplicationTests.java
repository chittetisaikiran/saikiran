package com.lti.customer_bankconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerBankconsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
